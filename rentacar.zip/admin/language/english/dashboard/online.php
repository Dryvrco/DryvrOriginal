<?php
// Heading
$_['heading_title'] = 'Total Agencies';

// Text
$_['text_view']     = 'View more...';