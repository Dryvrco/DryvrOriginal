<?php
// Heading
$_['heading_title'] = 'Total Bookings';

// Text
$_['text_view']     = 'View more...';