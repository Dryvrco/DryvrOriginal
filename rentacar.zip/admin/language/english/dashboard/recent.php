<?php
// Heading
$_['heading_title']     = 'Latest Bookings';

// Column
$_['column_order_id']   = 'Booking ID';
$_['column_customer']   = 'Customer';
$_['column_status']     = 'Status';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Date Added';
$_['column_action']     = 'Action';