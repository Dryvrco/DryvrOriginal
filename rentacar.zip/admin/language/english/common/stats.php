<?php
$_['text_complete_status']   = 'Bookings Completed'; 
$_['text_processing_status'] = 'Bookings Processing'; 
$_['text_other_status']      = 'Other Statuses'; 