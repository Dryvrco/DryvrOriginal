<?php
// Text
$_['text_footer'] 	= '<a href="http://www.efcoders.com" target="_blank">Efcoders</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';