<?php
// Heading
$_['heading_title'] = 'Total Income';

// Text
$_['text_view']     = 'View more...';