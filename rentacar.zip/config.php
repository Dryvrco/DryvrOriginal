<?php
// HTTP
define('HTTP_SERVER', 'http://dryvr.co/');

// HTTPS
define('HTTPS_SERVER', 'http://dryvr.co/');

// DIR
define('DIR_APPLICATION', '/home/dryvrc5/public_html/catalog/');
define('DIR_SYSTEM', '/home/dryvrc5/public_html/system/');
define('DIR_LANGUAGE', '/home/dryvrc5/public_html/catalog/language/');
define('DIR_TEMPLATE', '/home/dryvrc5/public_html/catalog/view/theme/');
define('DIR_CONFIG', '/home/dryvrc5/public_html/system/config/');
define('DIR_IMAGE', '/home/dryvrc5/public_html/image/');
define('DIR_CACHE', '/home/dryvrc5/public_html/system/cache/');
define('DIR_DOWNLOAD', '/home/dryvrc5/public_html/system/download/');
define('DIR_UPLOAD', '/home/dryvrc5/public_html/system/upload/');
define('DIR_MODIFICATION', '/home/dryvrc5/public_html/system/modification/');
define('DIR_LOGS', '/home/dryvrc5/public_html/system/logs/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'dryvrc5_ef');
define('DB_PASSWORD', 'iT0ZvTrT3NGM');
define('DB_DATABASE', 'dryvrc5_cars');
define('DB_PREFIX', 'oc_');
